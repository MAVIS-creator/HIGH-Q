<?php
// Redirect all traffic to public/index.php
require __DIR__ . '/public/index.php';
