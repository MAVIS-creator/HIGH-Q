<?php
// Public wrapper to central payments config
return require __DIR__ . '/../../config/payments.php';
