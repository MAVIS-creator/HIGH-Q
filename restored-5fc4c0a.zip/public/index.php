<?php
// public/index.php - canonical homepage loader
// We'll include the home content here. This file is the webserver's default index.
$pageTitle = 'High Q Solid Academy - Home';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/home.php';
include __DIR__ . '/includes/footer.php';

?>
