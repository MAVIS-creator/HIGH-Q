<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
$_GET['id'] = 22;
include __DIR__ . '/admin/api/export_registration.php';
